import java.sql.*;

public class Prueba {
	
	
	public static Connection connection;
	
	public static void main(String[] args) {
		
		try {
			Driver d= new org.postgresql.Driver();
			DriverManager.registerDriver(d);
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/postgres","postgres","Zorrogris01");
			
			String query = "select * from persona";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("Nombre") + " ");
				System.out.print(result.getInt("A�os") + " ");
				System.out.print(result.getString("Contrase�a") + " ");
				System.out.println(result.getInt("Dept") + " "); 
				System.out.println("----------------------------------------------------");
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
